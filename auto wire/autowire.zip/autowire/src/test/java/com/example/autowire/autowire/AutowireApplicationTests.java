package com.example.autowire.autowire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutowireApplicationTests {

	@Test
	void contextLoads() {
	}

}
